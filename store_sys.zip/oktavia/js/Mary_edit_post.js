//---------- Edit Mode ----------//

$(document).on('click','.Mary_admin-quill', function(){
    $('div .modife').css('opacity', '1').css('visibility', 'visible');
    $('div .modify_category').css('opacity', '1').css('visibility', 'visible');
    $('.Mary_mod_post').empty();
    $('.Mary_mod_category').empty();
    var array = ['title', 'textbox', 'date', 'id'],
        catArray = ['id', 'category'],
        n=-1,
        clickId = this.id;
    $('.Mary_del_post #' + clickId + "_" + clickId + ' td').each(function(){
        if(n != -1 && n < 4) {
            if(n == 1){
                var text = String($(this).html()).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/ /g, '&nbsp');
                $('.Mary_mod_post').append("<tr><td id="+array[n]+"><p class='before_input'>"+array[n]+"</p><textarea name='"+array[n]+"' class='"+array[n]+"' id='"+array[n]+"'>"+text+"</textarea></td></tr>");
            } else {
                $('.Mary_mod_post').append("<tr><td id="+array[n]+"><p class='before_input'>"+array[n]+"</p><input type='text' name='"+array[n]+"' class='"+array[n]+"' id='"+array[n]+"' value='"+$(this).html()+"'></td></tr>");
            }
        }
        n++;
    });
    $('.post_category #' + clickId + "-" + clickId + ' td').each(function(){
        if(n != -1 && n < 2) {
            $('.Mary_mod_category').append("<tr><td id="+catArray[n]+"><p class='before_input'>"+catArray[n]+"</p><input type='text' name='"+catArray[n]+"' class='"+catArray[n]+"' id='"+catArray[n]+"' value='"+$(this).html()+"'></td></tr>");
        }
        n++;
    });
});

//---------- Close Div Button ----------//

$(document).on('click','.cross1', function() {
    $('div .modife').css('opacity', '0').css('visibility', 'hidden');
    $('div .modify_category').css('opacity', '0').css('visibility', 'hidden');
    $('div .media_img_preview').css('opacity', '0').css('visibility', 'hidden').delay(1000).queue(function() {
        $(this).empty().dequeue();
    })
    console.log('close');
});

//---------- Add Post Editor ----------//

$(document).on('click', '#news', function() {
        $('#textbox').append('&lt;h2&gt;&lt;/h2&gt;&lt;p&gt;&lt;/p&gt;');
}).on('click', '#img', function() {
        $('#textbox').append('&lt;img src="" style="margin-left: 0;"&gt;');
}).on('click', '#play', function() {
        $('#textbox').append('&lt;iframe src="" frameborder="0" allowfullscreen=""&gt;&lt;/iframe&gt;');
}).on('click', '#music', function() {
        $('#textbox').append('&lt;iframe width="100%" height="426" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/$$HERE IS YOUR TRACK$$&amp;auto_play=false&amp;hide_related=true&amp;show_comments=false&amp;show_user=false&amp;show_reposts=false&amp;visual=true"&gt;&lt;/iframe&gt;');
}).on('click', '#embed', function() {
        $('#textbox').append('&lt;div&gt;&lt;/div&gt;');
}).on('click', '#maps', function() {
        $('#textbox').append('<h2></h2><p></p>');
});

//---------- Media Gallery ----------//

$(document).on('click', '.img_preview', function() {
    $('.media_img_preview').empty().css('opacity', '1').css('visibility', 'visible');
    var imgId = this.id;
    console.log(imgId);
    $('.tab-2 .workspace_tab .media_img_preview').append('<table class="img_full_preview" id="img_full_preview"></table>');
    $.ajax({
        url: 'components/moduls/media/img_info.php',
        type: 'POST',
        data: ({id: imgId}),
        success: function(data){
            $('#img_full_preview').html(data);
        }
    });
    
});

//---------- Save Tab Position ----------//

(function($) {
    var tabs = document.getElementsByName("list_of_tabs");
    $(function() {
        $('div .list_of_tabs input[type="radio"]').not(":checked").on('click', function() {
            $('.list_of_tabs').find('input[type="radio"]').removeAttr("checked");
            $(this).attr('checked', 'checked');
            this.checked = true;
            for (var i = 0; i < tabs.length+1; i++) {
                localStorage.setItem('tab_item'+i, $('#tab-'+i).attr("checked"));
            }
        });
        for (var i = 0; i < tabs.length+1; i++) {
            var n = localStorage.getItem("tab_item"+i);
            if(n == 'undefined') {
                $('.list_of_tabs .tab-'+i).removeAttr("checked");
            } else {
                $('.tab-'+i).attr('checked', 'checked');
            }
        }  
    });   
})(jQuery);

//---------- Search Image ----not work yet------//

(function(document) {
    'use strict';
    var LightTableFilter = (function(Arr) {
        var _input;
        function _onInputEvent(e) {
            _input = e.target;
            var tables = document.getElementsByClassName(_input.getAttribute('data-div'));
            Arr.forEach.call(div, _filter);
        }

        function _filter(div) {
            var text = div.textContent.toLowerCase(), val = _input.value.toLowerCase();
            div.style.display = text.indexOf(val) === -1 ? 'none' : 'table-div';
        }

        return {
            init: function() {
                var inputs = document.getElementsByClassName('light-table-filter');
                Arr.forEach.call(inputs, function(input) {
                    input.oninput = _onInputEvent;
                });
            }
        };
    })(Array.prototype);

    document.addEventListener('readystatechange', function() {
        if (document.readyState === 'complete') {
            LightTableFilter.init();
        }
    });

})(document);

//---------- Toggle Scroll Class ----------//

(function($) {
    $('.inner_post').queue(function(){
        if($(this).height() >= "500") {
            $('.del').addClass('Astrid_scroll').addClass('Astrid_admin_comments');
        }
        $(this).dequeue();
    });
})(jQuery);

//--------- Open Codebox ----------//

(function($) {
    var isAlt = false;
    $(document).keyup(function (e) {
        if(e.which == 13) {
            $.getJSON( "../protected/tests/json/test.json", function( data ) {
                var words = [];
                var output = data;
                $.each( data, function( key, val ) {
                  words.push(key);
                });
                var input = $('.codebox_input').val();
                $.ajax({
                    url: '../protected/tests/levenshtein/levenshtein.php', 
                    type: "POST",
                    data: ({array: words, input: input}),
                    success: function(data){
                        $.each(output, function(key, val) {
                            if(data == key) {
                                if (~val.indexOf("|")) {
                                    var randArray = val.split("|")
                                    var valRand = Math.floor(Math.random() * randArray.length);
                                    $('.codebox_input_answer').val(randArray[valRand]);
                                    $('.codebox_input').val('');
                                } else {
                                    $('.codebox_input_answer').val(val);
                                    $('.codebox_input').val('');
                                }
                            }
                        });
                    }
                });       
            });
        }
        if(e.which == 18) isAlt=false;
    }).keydown(function (e) { 
        if(e.which == 18) isAlt=true;
        function greetings() {
            var greet = ["Hello!", "Namaste!", "Bonjour!", "Hola!", "Aloha!"];
            var rand = Math.floor(Math.random() * greet.length);
            $('.codebox_input_answer').val(greet[rand]);
        }
        if(e.which == 81 && isAlt == true) {
            if ($('.codebox').css('display') == 'none'){
                $('.codebox').show();
                greetings();
                $('#cube').removeClass('show-front').addClass('show-right');
            } else{
                $('.codebox').hide();
                $('#cube').removeClass('show-right').addClass('show-front');
            }
            return false;
    }
});
})(jQuery);

//---------- Get Generated Password and Checking it's Strength ----------//

(function($) {
    var shortPass = 'Too short'
    var badPass = 'Bad'
    var goodPass = 'Good'
    var strongPass = 'Strong'
    function passwordStrength(password) {
        score = 0 
        if (password.length < 4 ) { return shortPass }
        score += password.length * 4
        //password has 3 numbers
        if (password.match(/(.*[0-9].*[0-9].*[0-9])/))  score += 5 
        //password has 2 sybols
        if (password.match(/(.*[!,@,#,$,%,^,&,*,?,_,~].*[!,@,#,$,%,^,&,*,?,_,~])/)) score += 5    
        //password has Upper and Lower chars
        if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))  score += 10 
        //password has number and chars
        if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/))  score += 15 
        //password has number and symbol
        if (password.match(/([!,@,#,$,%,^,&,*,?,_,~])/) && password.match(/([0-9])/))  score += 15 
        //password has char and symbol
        if (password.match(/([!,@,#,$,%,^,&,*,?,_,~])/) && password.match(/([a-zA-Z])/))  score += 15 
        //password is just a nubers or chars
        if (password.match(/^\w+$/) || password.match(/^\d+$/) )  score -= 10 
        //verifing 0 < score < 100
        if ( score < 0 )  score = 0 
        if ( score > 100 )  score = 100 
        if (score < 34 )  return badPass 
        if (score < 68 )  return goodPass
        return strongPass
    }
    $('#gen').click(function(){
        $.get('../../tests/genpass/newpass.php', function(data) {
                $('#password').val(data);
                $('#result').html(passwordStrength($('#password').val()));
            }
        );
    })
    $('#password').keyup(function(){$('#result').html(passwordStrength($('#password').val()))});
})(jQuery);
