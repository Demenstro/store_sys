<?php
$score = "1";    
$userAnswer = $_POST['name'];    
if ($_POST['name'] == "145"){
    $score++;
}       
echo $score;    
?>