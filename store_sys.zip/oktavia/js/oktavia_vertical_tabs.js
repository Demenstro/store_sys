toggleTab = function(targetTab) {

    // Nothing to do if already active tab
    if (targetTab.hasClass('active')) {
        return;
    }

    // Find and cache the current tab component.
    // Important for when page has multiple
    // tab components
    var component = targetTab.closest('.vertical-tabs');
    var panels = component.find('.vertical-tabs-panel');
    var tabs = component.find('.vertical-tabs-menu li');

    // Remove active status to all tabs and
    // tab panels
    panels.removeClass('active-panel');
    tabs.removeClass('active');

    // Set the new target tab and panel status to
    // active
    var targetPanelId = targetTab.data('target');
    var targetPanel = $('#' + targetPanelId);
    targetPanel.addClass('active-panel');
    targetTab.addClass('active');
}

$( document ).ready(function() {
    // Activate click event on menu to trigger
    // the toggle tab function
    $('.vertical-tabs-menu li').on('click', function(){
        toggleTab($(this));
    });
});