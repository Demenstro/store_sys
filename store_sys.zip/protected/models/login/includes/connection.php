
<?php
require("constants.php");

$connection = mysql_connect(DB_SERVER, DB_USER, DB_PASS) or die(mysql_error());
$db = mysql_select_db(DB_NAME, $connection) or die(mysql_error());