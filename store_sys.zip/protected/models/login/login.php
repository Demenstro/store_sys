<?php
session_start();
require_once("includes/connection.php"); 
include("includes/header.php"); 

if(isset($_SESSION["session_username"])) {
header("Location: intropage.php");
}

if(isset($_POST["login"])){
    if(!empty($_POST['username']) && !empty($_POST['password'])) {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $query =mysql_query("SELECT * FROM oktavia_login_username WHERE login='".$username."' AND password='".$password."'");
        $numrows=mysql_num_rows($query);
        if($numrows!=0) {
            while($row=mysql_fetch_assoc($query)) {
                $dbusername=$row['login'];
                $dbpassword=$row['password'];
            }
            if($username == $dbusername && $password == $dbpassword) {
                $_SESSION['session_username']=$username;

                echo mysql_query("UPDATE oktavia_login_username SET logged_in='Yes' WHERE login='".$username."'");

                header("Location: intropage.php");
            }
        } else {
            $message =  "Invalid username or password!";
        }
    } else {
        $message = "All fields are required!";
    }
}
?>

    <div class="container mlogin">
            <div id="login">
    <h1>LOGIN</h1>
<form name="loginform" id="loginform" action="" method="POST">
    <p>
        <label for="user_login">Username<br />
        <input type="text" name="username" id="username" class="input" value="" size="20" /></label>
    </p>
    <p>
        <label for="user_pass">Password<br />
        <input type="password" name="password" id="password" class="input" value="" size="20" /></label>
    </p>
        <p class="submit">
        <input type="submit" name="login" class="button" value="Log In" />
    </p>
        <p class="regtext">No account yet? <a href="register.php" >Register Here</a>!</p>
</form>

    </div>

    </div>
	
	<?php include("includes/footer.php"); ?>
	
	<?php if (!empty($message)) {echo "<p class=\"error\">" . "MESSAGE: ". $message . "</p>";} ?>
	