(function($) {
	$.getJSON( "playlists.json", function( data ) {
		$.each( data, function( key, val ) {
            $('#playlist').append('<option>' + key + '</option>');
        });
	});
	//$('.likeButton').css('display','none');
	$('.sc-button-buy').css('display','none');
	//$('.sc-button-share').css('display','none');
	//$('.soundHeader__logo').css('display','none');
	//$('.cookiePolicy').css('display','none');
	//$('.paging-eof').css('display','none');
})(jQuery);