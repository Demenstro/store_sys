<?php
$playlist = $_POST['playlist'];
$json = file_get_contents('playlists.json');
$obj = json_decode($json);
$playlist = $obj->$playlist;
echo '<link media="screen" href="style.css" rel="stylesheet" type="text/css"><script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script><script type="text/javascript" src="getPlayList.js"></script>';
echo '<iframe width="245" height="494" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/'.$playlist.'&amp;color=00FFD2&amp;auto_play=false&amp;hide_related=false&amp;show_comments=false&amp;show_user=false&amp;show_reposts=false&amp;visual=false"></iframe>';
echo '<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script><script type="text/javascript" src="getPlayList.js"></script><script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script>';