<?php 
session_start();
require_once("includes/connection.php");
$username = $_SESSION['session_username'];
if(isset($_POST['logoutbtn'])) {
	echo mysql_query("UPDATE oktavia_login_username SET logged_in='No' WHERE login='".$username."'");
}
unset($_SESSION['session_username']);
session_destroy();
header("location:login.php");

?>
