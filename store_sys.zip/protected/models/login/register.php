<?php 
	require_once("includes/connection.php");
	include("includes/header.php"); 
	if(isset($_POST["register"])){
		if(/*!empty($_POST['fullname']) && */!empty($_POST['email']) && !empty($_POST['username']) && !empty($_POST['password'])) {
			$fullname=$_POST['fullname'];
			$email=$_POST['email'];
			$username=$_POST['username'];
			$password=$_POST['password'];
			$query=mysql_query("SELECT * FROM oktavia_login_username WHERE login='".$username."'");
			$numrows=mysql_num_rows($query);
			if($numrows==0) {
				echo $fullname;
				$result=mysql_query("INSERT INTO oktavia_login_username (fullname, email, login,password) VALUES('$fullname','$email', '$username', '$password')");
				if($result){
				 $message = "Account Successfully Created";
				} else {
				 $message = "Failed to insert data information!";
				}
			} else {
			 $message = "That username already exists! Please try another one!";
			}
		} else {
			 $message = "All fields are required!";
		}
	}
	if (!empty($message)) {echo "<p class=\"error\">" . "MESSAGE: ". $message . "</p>";} 
?>
<script async type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script>
<div class="container mregister">
	<div id="login">
	<h1>REGISTER</h1>
		<form name="registerform" id="registerform" action="register.php" method="post">
			<p>
				<label for="user_login">Full Name<br />
				<input type="text" name="fullname" id="fullname" class="input" size="32" value=""  /></label>
			</p>
			<p>
				<label for="user_pass">Email<br />
				<input type="email" name="email" id="email" class="input" value="" size="32" /></label>
			</p>
			<p>
				<label for="user_pass">Username<br />
				<input type="text" name="username" id="username" class="input" value="" size="20" /></label>
			</p>
			<p>
				<label for="user_pass">Password<br />
				<input type="text" name="password" id="password" class="input" value="" size="32" /></label>
				<input type="button" name="gen" class="button" value="Generate" id="gen">
				<div id='result'></div>
			</p>	
			<p class="submit">
				<input type="submit" name="register" id="register" class="button" value="Register" />
			</p>
			<p class="regtext">Already have an account? <a href="login.php" >Login Here</a>!</p>
		</form>
	</div>
</div>
<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script>
<script type="text/javascript" src="../../../oktavia/js/Mary_edit_post.js"></script>
<script language="javascript">
	jQuery(document).ready(function() {
		$('#password').keyup(function(){$('#result').html(passwordStrength($('#password').val()))})
	})
</script>
<?php 
	include("includes/footer.php"); 
?>