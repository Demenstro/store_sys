<?php 
	session_start();
	if(!isset($_SESSION["session_username"])) {
		header("location:login.php");
	} else {
	require_once("includes/connection.php"); 
	include("includes/header.php");
	$user = $_SESSION['session_username']; 
	$query = mysql_query("SELECT * FROM oktavia_login_username WHERE login='".$user."'") or die(mysql_error());
	while($row = mysql_fetch_assoc($query)) {
		$logged_in = $row['logged_in'];
        if($logged_in == 'Yes') {
        	$message = "Line 1\r\nLine 2\r\nLine 3";
			$message = wordwrap($message, 70, "\r\n");
			mail('ruslan.dragan34@gmail.com', 'My Subject', $message);
			echo "mail";
        }
	}
?>
		<div id="welcome">	
			<h2>Welcome, <span><?php echo $_SESSION['session_username'];?>! </span></h2>
			<form name="logoutform" id="logoutform" action="logout.php" method="POST"><p>
				<input type="hidden" value="<?php echo $_SESSION['session_username'];?>">
		        <input type="submit" name="logoutbtn" class="button" value="Log Out" />
				<!--<a href="logout.php">Logout</a> Here!</p>-->
			</form>
		</div>
<?php 
	include("includes/footer.php"); 
}
?>
