<html>
<head>
<title>Проверка метода POST в PHP</title>
</head>
<body>
<?php
echo ($_POST["num"]."<br>");
echo ($_POST["type"]."<br>");
echo ($_POST["v"]);
?>
</body>
</html>