
<head><script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script></head>
<body>
	<form action='sc.php' method='POST'>
		<select name='playlist' id='playlist'>
		</select>
		<input type="submit" name='button' value='Select'>
	</form>
	<script type='text/javascript' src='getPlayList.js'></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script>
</body>
