<html>
<head>
<title>Форма для передачи данных методом POST и PHP</title>
</head>
<body>
<form action="script.php" method="POST" >
Введите число <input type="text" name="num" value="" /><br/>
У Вас есть компьютер? <select name="type">
<option value="yes">Да</option>
<option value="no">Нет</option>
</select><br/>
Ваш комментарий:<br/>
<textarea name="v" ></textarea><br/>
<input type="submit" name="bsubmit" value="Отправить" />
</form>
</body>
</html>
