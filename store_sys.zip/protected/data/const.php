<?php

// Oktavia admin-panel const
define("MARY_BLOG_NAME", "Oktavia");
define("MARY_ADMIN_LOGOUT","Log Out");
define("WALL_POSTS","Wall Posts");
define("ADD_POST","Add Post");
define("CATEGORIES","Categories");
define("ADD_CATEGORY","Add Category");
define("EDIT_MODE","Edit Mode");
define("TITLE","Title");
define("TEXTBOX","Textbox");
define("DATE","Date");
define("ID","Id");
define("CATEGORY","Category");
define("DELETE","Delete");
define("MODIFY","Modify");
define("ADD","Add");
define("MEDIA","Media");
define("FILE_NAME","File name");
define("FILE_TYPE","File type");
define("FILE_SIZE","File size");
define("UPLOADED","Uploaded");
define("PROPORTIONS","Proportions");
define("NAME","Name");
define("DESCRIPTION","Description");
define("USER","User");
define("SAVE","Save");
define("PAGES","Pages");
define("SETTINGS","Settings"); 