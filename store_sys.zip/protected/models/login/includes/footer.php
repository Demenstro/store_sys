<footer>© 2016 <a href="#">Oktavia</a>. All rights reserved. </footer>	
</body>
</html>
