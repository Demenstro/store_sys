<?php
function register($username, $password) {
    $hash = password_hash($password, PASSWORD_BCRYPT);
    echo $hash;
    echo "<br>";
    echo $password;
    if(password_verify($password, $hash)) {
    	echo "<br>Хорошооо пошло";
    } else {
    	echo "<br>Чёт не пошло";
    }
}
register('demenstro','mister');
?>