<?php

$words = $_POST['array'];
$input = $_POST['input'];

//$input = 'apple mustard by the way';
//$words  = array('apple pie way by','pineapple','banana','orange',
  //              'radish','carrot','pea','bean','potato');
$shortest = -1;
foreach ($words as $word) {
    $lev = levenshtein($input, $word);
    if ($lev == 0) {
        $closest = $word;
        $shortest = 0;
        break;
    }
    if ($lev <= $shortest || $shortest < 0) {
        $closest  = $word;
        $shortest = $lev;
    }
}
/*echo "Вы ввели: $input\n";
if ($shortest == 0) {
    echo "Найдено точное совпадение: $closest\n";
} else {
    echo "Вы не имели в виду: $closest?\n";
}*/
echo $closest;
