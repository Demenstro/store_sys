<?php
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    echo $username, $password;
    $connection = mysql_connect("localhost", "root", "");
    $db = mysql_select_db("oktavia", $connection);
    $query = mysql_query("SELECT * FROM oktavia_login_username WHERE password='$password' AND username='$username'", $connection);
    $rows = mysql_num_rows($query);
    if ($rows == 1) {
        $_SESSION['login_user'] = $username;
        echo 1;
        //header("location: test2.php");
    } else {
        echo $error = "Username or Password is invalid";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<div id="main">
    <div id="login">
        <form action="" method="post">
            <label>UserName :</label>
            <input id="name" name="username" placeholder="username" type="text">
            <label>Password :</label>
            <input id="password" name="password" placeholder="**********" type="password">
            <input name="submit" type="submit" value=" Login ">
        </form>
    </div>
</div>
</body>
</html>