<textarea class="codebox_input_answer" readonly></textarea>
<input type="text" name="codebox" placeholder="Hello, man!" class="codebox_input">


