<?php
/* $dir = '../images/'; // Папка с изображениями
  $cols = 3; // Количество столбцов в будущей таблице с картинками
  $files = scandir($dir); // Берём всё содержимое директории
  echo "<table>"; // Начинаем таблицу
  $k = 0; // Вспомогательный счётчик для перехода на новые строки
  for ($i = 0; $i < count($files); $i++) { // Перебираем все файлы
    if (($files[$i] != ".") && ($files[$i] != "..")) { // Текущий каталог и родительский пропускаем
      if ($k % $cols == 0) echo "<tr>"; // Добавляем новую строку
      echo "<td>"; // Начинаем столбец
      $path = $dir.$files[$i]; // Получаем путь к картинке
      echo "<a href='$path'>"; // Делаем ссылку на картинку
      echo "<img src='$path' alt='' width='100' />"; // Вывод превью картинки
      echo "</a>"; // Закрываем ссылку
      echo "</td>"; // Закрываем столбец
      
      if ((($k + 1) % $cols == 0) || (($i + 1) == count($files))) echo "</tr>";
      $k++; // Увеличиваем вспомогательный счётчик
    }
  }
  echo "</table>"; // Закрываем таблицу*/
?>
<?php
/*$basedir = "../images";  //Директория для папок c картинками
$thumbs = "thumbs";
$get_img = $_GET['images'];
 
if(!$get_img){
        echo "<b>Выберите папку</b><br>";
        $handler = opendir($basedir);
        while(($file = readdir($handler)) !== FALSE){
                if(is_dir($basedir."/".$file) && $file != "." && $file != ".." && $file != $thumbs){
                        echo "<a href='?images=$file'>$file</a><br>"; //вырезали '.', '..', 'thumbs', вывели название папок с картинками в виде ссылки
                }
        }
} else{
        if((!is_dir($basedir."/".$get_img)) || strstr($get_img,".") != NULL || strstr($get_img,"/") != NULL || strstr($get_img,"\\") != NULL){
                echo "Папки не существует"; //защита от неверных get параметров
        } else{  //если get сущ. открываем дир. с картинками
                echo "<b>$get_img</b><br>";
                $handler = opendir($basedir."/".$get_img);
                while(($file = readdir($handler)) !== FALSE){
                        if($file != "." && $file != ".."){
                                //выводим картинки
                                echo "<u><li style='display:inline; padding:5px; list-style:none'><img src='$basedir/$get_img/$file' height='200' width='200'/></li></ul>";
                        }
                }
        }
}*/
?>
<?php 
echo '<input type="search" class="light-table-filter" data-div="order-div" placeholder="Filtrer" />
<div class="order-div">';
$dir = '../images';
function scan($dir)
{
        $d = array();
        $arr = opendir($dir);
        $n = 0;
        while($v = readdir($arr))
        {		
                if($v == '.' or $v == '..') continue;
                if(!is_dir($dir.'/'.$v)) {
                	$file = (string)($d[] = $v);
                	echo '<div style="display: inline;" id="img_preview-'.$v.'"><img class="img_preview" id="'.$dir.'/'.$v.'" style="margin:20px; width:200px !important; height:200px !important;" src="'.$dir.'/'.$file.'" alt=""></div>';
                	$n++;
                }
                if(is_dir($dir.'/'.$v)) {
                	$d[$v] = scan($dir.'/'.$v);
                	//echo '<a href="'.$dir.'/'.$v.'">'.$v.'</a>';
                } 
                $n++;
   }
 
        return $d;
}
scan($dir);
echo '</div><div class="media_img_preview"></div>';
?>