<?php
require('../../../../protected/data/const.php'); 
session_start();
//error_reporting(0);
$post_installed_dir = '';
//parse img path
$imgId = $_POST['id'];
$img_name = basename($imgId);
$imgIdr = str_replace('..', '', $imgId);
$img_name_explode = explode('.', $img_name);
// parse referer

//for sites may this be good
/*http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])s."/".$relative_url);*/

$explode_http_referer = explode('/', $_SERVER["HTTP_REFERER"]);
$http_type = $explode_http_referer[0];//http:
$server_name = $explode_http_referer[2];//localhost
$installed_dir = $explode_http_referer[3];//store_sys
if ($post_installed_dir == $server_name) {
	$installed_dir = '';
}
$img_path = $http_type.'//'.$server_name.'/'.$installed_dir.$imgIdr;
// type & proportions
list($width, $height, $img_type, $attr) = getimagesize($img_path);
// filesize
if($server_name != 'localhost') {
	if (file_exists($img_path)) {
		$img_filesize = filesize($img_path);
		$img_filetime = filectime($img_path);
	}
} else {
	$localhost_path = 'D:\xampp\htdocs'.'/'.$installed_dir.$imgIdr;
	$img_filesize = round(filesize($localhost_path)/1000, 1).' kB';
	$img_filetime = date('D  d/M/Y h:i A', filectime($localhost_path));
}

echo '<tr>
		<td style="width: 100%;">
			<div class="img_side">
				<img src='.$imgId.'>
			</div>
		</td>
		<td style="border-left: solid 1px white;">
			<div class="img_info_side">
			<div class="cross1 Mary_admin_cross-cross"></div>
				<div class="details">
					<div class="filename"><strong>'.FILE_NAME.':</strong> '.$img_name_explode[0].'</div>
					<div class="filetype"><strong>'.FILE_TYPE.':</strong> image/'.$img_name_explode[1].' </div>
					<div class="filesize"><strong>'.FILE_SIZE.':</strong> '.$img_filesize.' </div>
					<div class="uploaded"><strong>'.UPLOADED.':</strong> '.$img_filetime.'</div>
					<div class="dimensions"><strong>'.PROPORTIONS.':</strong> '.$width.' × '.$height.'</div>
				</div>
				<hr class="img_hr">
				<div class="settings">
					<div class="img_path_div"><span>URL: </span><input type="text" class="img_path_input" name="img_path_input" value=" '.$img_path.'" readonly></div>
					<div class="img_name_div"><span>'.NAME.': </span><input type="text" class="img_name_input" name="img_name_input" value=" '.$img_name_explode[0].'"></div>
					<div class="img_alt_div"><span>Alt: </span><input type="text" class="img_alt_input" name="img_alt_input" value=""></div>
					<div class="img_description_div"><span>'.DESCRIPTION.': </span><input type="text" class="img_description_input" value=""></div>
					<div class="img_user_div"><span>'.USER.': </span><input type="text" class="img_user_input" value="'.$_SESSION["session_username"].'" readonly>
					<input type="submit" name="save" value="'.SAVE.'" style="position:absolute;margin-top: 25px; float:right;">
				</div>	
			</div>
		</td>
	</tr>';
?>
