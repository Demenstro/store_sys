<?php
require("../protected/data/const.php");
require("../protected/models/login/includes/connection.php");
session_start();
if(!isset($_SESSION['session_username'])){
    header("location: ../protected/models/login/login.php");
}
$dbtable = 'oktavia_liric_table';
$checking = 'id';
$cols = array('title', 'textbox', 'date', 'id');
$text_icons = array('video', 'img', 'href', '', '');
$category_cols = array('id', 'category');
?>
<head>
    <link media="screen" href="../css/oktavia_admin.css" rel="stylesheet" type="text/css">
    <script async type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script>
    <script async type="text/javascript" src="js/time.js"></script>
    <script async type="text/javascript" src="js/Mary_edit_post.js"></script>
    <script async type="text/javascript" src="js/oktavia_vertical_tabs.js"></script>
</head>
<body>
<div>
    <div class = "admin_menu">
        <div class = "logo_space">
            <div class = "admin_logo"></div>
            <b id="logout">
                <a class = "Mary_admin_logout" href="../protected/views/site/logout.php">
                    <?php echo MARY_ADMIN_LOGOUT ?>
                </a>
            </b>
        </div>
        <div class="time_space">
            <div class = "Mary_blog_name">
               <?php echo MARY_BLOG_NAME ?>
            </div>
            <hr style = "width:100%; margin: 8px;">
            <div class = "Mary_time" id = "Mary_time"></div>
            <div class = "Mary_date">
                <?php
                    echo date('D d/M/Y'); ?>
            </div>
        </div>
        <hr style = "margin-top: 20px;">
        <section class="cube-container">
          <div id="cube">
            <figure class="front">
                <div class="Astrid_admin_comments Astrid_scroll">
                    <div class="Astrid_inner">
                    <?php
                    $astridComments = mysql_query("SELECT comm.comment_text AS comm, postbox.title AS postbox FROM oktavia_post_comments comm JOIN oktavia_liric_table postbox WHERE comm.post_id = postbox.id ORDER BY comment_id DESC LIMIT 15") or die(mysql_error());
                    while($astridComment = mysql_fetch_array($astridComments)) {
                        $comm = $astridComment["postbox"];
                        $points ='';
                        if(strlen($comm) > 25) {
                            substr($comm, 0, 25);
                            $points = '..';
                        } else {
                            $points = '';
                        }
                        echo '<div class = "Astrid_comments"><div class="Astrid_mini_logo"></div><b class="Astrid_comment_user">'.
                             $comm, $points.'</b><p class="Astrid_comment_text">'.trim($astridComment["comm"]).'</p></div>';

                    }
                    ?>
                    </div>
                </div>
            </figure>
            <figure class="right">
                <div class="codebox">
                    <?php require_once("components/moduls/codebox/codebox.php"); ?>
                </div>
            </figure>
          </div>
        </section>
            
    </div>
    <div class = "Mary_workspace">
        <div class="area-total-tabs">
            <div class="list_of_tabs animation-flip">
                        <input style="display:none;" type="radio" name="list_of_tabs" checked="checked" id="tab-0" class="tab-0 save">
                        <label style="display:none;" class="Mary_tab" for="tab-0"><span><span><i class = "Mary_admin-newspaper"></i>  Test tab</span></span></label>

                        <input type="radio" name="list_of_tabs" id="tab-1" class="tab-1 save">
                        <label class="Mary_tab" for="tab-1"><span><span><i class = "Mary_admin-newspaper"></i>  <?php echo  WALL_POSTS ?></span></span></label>

                        <input type="radio" name="list_of_tabs" id="tab-2" class="tab-2 save">
                        <label class="Mary_tab" for="tab-2"><span><span><?php echo MEDIA ?></span></span></label>

                        <input type="radio" name="list_of_tabs" id="tab-3" class="tab-3 save">
                        <label class="Mary_tab" for="tab-3"><span><span><?php echo PAGES ?></span></span></label>

                        <input type="radio" name="list_of_tabs" id="tab-4" class="tab-4 save">
                        <label class="Mary_tab" for="tab-4"><span><span><i class = "Mary_admin-cogs"></i><?php echo SETTINGS ?></span></span></label>

                <hr class = "admin_hr">
                <ul>
                    <li class="tab-0">
                        <div class="workspace_tab">
                            Start page!
                        </div>
                    </li>
                    <li class="tab-1">
                        <div class="workspace_tab">
                            <div class="vertical-tabs">
                                <div class="vertical-tabs-menu">
                                    <ul>
                                        <li data-target="option1" class="active"><?php echo  WALL_POSTS ?></li>
                                        <li data-target="option2"><?php echo  ADD_POST ?></li>
                                        <li data-target="option3"><?php echo  CATEGORIES ?></li>
                                        <li data-target="option4"><?php echo  ADD_CATEGORY ?></li>
                                    </ul>
                                </div>
                                <div class="vertical-tabs-content">
                                    <div id="option1" class="vertical-tabs-panel active-panel">
                                        <form method="post" action="oktavia_administrator_misc.php" style="color:white;">
                                            <div class = "del">
                                                <div class="inner_post">
                                                    <h1><?php echo  WALL_POSTS ?></h1>
                                                    <?php
                                                        $posts = mysql_query("SELECT * FROM $dbtable ORDER BY date DESC");
                                                        if($posts) {
                                                            echo "<table class='Mary_del_post'>";
                                                            while($post = mysql_fetch_array($posts)) {
                                                                echo "<tr class = 'hover_tr' id=$post[$checking]_$post[$checking]><td><input type='checkbox' name=checkbox[] value=$post[$checking] id = '$post[$checking]'></td>";
                                                                foreach ($cols as $value) {
                                                                    if($value == 'textbox') {
                                                                        echo "<td style = 'display:none;' id=$post[id]_$value>".$post[$value]."</td>";
                                                                    } elseif ($value == 'id') {
                                                                        echo "<td id=$post[id]_$value>" . $post[$value] . "</td><td class = 'Mary_quill'>
                                                                             <label class='choice' for='".$post[$checking]."'><div class = 'Mary_admin-quill' id=$post[id]></div></label></td>";
                                                                    } else {
                                                                        echo "<td id=$post[id]_$value>" . $post[$value] . "</td>";
                                                                    }
                                                                }
                                                            }
                                                            echo "</tr></table><div class='first'></div>";
                                                        } else {
                                                            echo "<p><b>Error: ".mysql_error()."</b><p>";
                                                            exit();
                                                        }
                                                        echo "<input type='submit' name='delete' value=".DELETE." style = 'position:absolute;margin-top: 25px;'>";
                                                        $cols = implode(',', $cols);
                                                        echo "<input type='hidden' value=$dbtable name='row'>
                                                              <input type='hidden' value=$checking name='column'>
                                                              <input type='hidden' value=$cols name='cols'>";
                                                    ?>
                                                </div>
                                            </div>
                                            <div class = "modife">
                                                <h1 style="display:inline-block"><?php echo  EDIT_MODE ?></h1><div class="cross1 Mary_admin_cross-cross"></div>
                                                <table class = 'Mary_mod_post'>
                                                </table>
                                                <input type='submit' name='mod' value='<?php echo  MODIFY ?>' style='margin-top:25px;'>
                                                <?php
                                                    echo "<input type='hidden' value=$dbtable name='row'>
                                                          <input type='hidden' value=$checking name='column'>
                                                          <input type='hidden' value=$cols name='cols'>";
                                                ?>
                                            </div>
                                        </form>
                                    </div>
                                    <div id="option2" class="vertical-tabs-panel">
                                        <h1><?php echo ADD_POST ?></h1>
                                        <?php
                                            error_reporting( E_ERROR );
                                            $cols = array('title', 'textbox', 'date');
                                            $dbtable = 'oktavia_liric_table';
                                        ?>
                                        <form method="post" action="oktavia_administrator_misc.php">
                                            <?php
                                                echo "<table class = 'add'>";
                                                foreach ($cols as $val) {
                                                    if($val == 'textbox'){
                                                        echo "<tr><td><p class='before_input'>$val</p><textarea name=$val class=$val id=$val></textarea></td></tr>";
                                                    } elseif($val == 'date'){
                                                        $time = date("Y-m-d H:i:s");
                                                        echo "<tr><td><p class='before_input'>$val</p><input formenctype='multipart/form-data' name=$val type='text' class=$val value='$time'></td></tr>";
                                                    } else {
                                                        echo "<tr><td><p class='before_input'>$val</p><input name=$val type='text' class=$val></td></tr>";
                                                    }
                                                }
                                                echo "</table>";
                                                echo "<input type='submit' name='add' value='".ADD."' style='position:absolute; margin-top:25px; display: block;'><div class ='text_icons'>
                                                      <div class='Mary_admin-newspaper complete' id='news'></div><div class='Mary_admin-image complete' id='img'></div>
                                                      <div class='Mary_admin-play complete' id='play'></div><div class='Mary_admin-headphones complete' id='music' ></div>
                                                      <div class='Mary_admin-embed2 complete' id='embed'></div><div class='Mary_admin-map complete' id='map'></div></div>";
                                                $cols = implode(',', $cols);
                                                echo "<input type='hidden' value=$cols name='cols'>";
                                                echo "<input type='hidden' value=$dbtable name='row'>";
                                            ?>
                                        </form>
                                    </div>
                                    <div id="option3" class="vertical-tabs-panel">
                                        <h1><?php echo  CATEGORIES ?></h1>
                                        <form method="post" action="oktavia_administrator_misc.php">
                                            <div class="del_category">
                                            <?php
                                                $categories = mysql_query("SELECT category, id FROM oktavia_category ORDER BY id ") or die(mysql_error());
                                                if($categories) {
                                                    echo "<table class='post_category'>";
                                                    while($category = mysql_fetch_array($categories)) {
                                                        $cat = $category["category"];
                                                        $id = $category["id"];
                                                        echo "<tr class='hover_tr' id=$id-$id><td><input type='checkbox' name=checkbox[] value=$id id = '$id'></td>";
                                                        foreach($category_cols as $cat_val) {
                                                            if($cat_val == 'id') {
                                                                echo "<td id=$id-$cat_val>" . $category[$cat_val] . "</td>";
                                                            } elseif ($cat_val == 'category') {
                                                                echo "<td id=$id-$cat_val>" . $category[$cat_val] . "</td><td class = 'Mary_quill'>
                                                                      <label class='choice' for='".$id."'><div class = 'Mary_admin-quill' id=$id></div></label></td>";
                                                            } else {
                                                                echo "<td id=$id-$cat_val>" . $category[$cat_val] . "</td>";
                                                            }
                                                        }
                                                    }
                                                    echo "</tr></table> ";
                                                } else {
                                                    echo "<p><b>Error: ".mysql_error()."</b><p>";
                                                    exit();
                                                }
                                                echo "<input type='submit' name='delete' value='".DELETE."' style = 'position:absolute;margin-top: 25px;'>";
                                                $category_cols = implode(',', $category_cols);
                                                echo "<input type='hidden' value=$category_cols name='cols'>
                                                      <input type='hidden' value=$checking name='column'>
                                                      <input type='hidden' value='oktavia_category' name='row'>";
                                            ?>
                                            </div>
                                            <div class="modify_category">
                                                <h1 style="display:inline-block"><?php echo  EDIT_MODE ?></h1><div class="cross1 Mary_admin_cross-cross"></div>
                                                <table class="Mary_mod_category">
                                                </table>
                                                <input type='submit' name='mod' value='<?php echo  MODIFY ?>' style='margin-top:25px;'>
                                                <?php 
                                                    echo "<input type='hidden' value=$category_cols name='cols'>
                                                          <input type='hidden' value=$checking name='column'>
                                                          <input type='hidden' value='oktavia_category' name='row'>";
                                                ?>
                                            </div>
                                        </form>
                                    </div>
                                    <div id="option4" class="vertical-tabs-panel">
                                        <h1><?php echo  ADD_CATEGORY ?></h1>
                                        <form method="post" action="oktavia_administrator_misc.php">
                                            <?php
                                                $category_cols = explode(',', $category_cols);
                                                echo "<table class = 'add_category'>";
                                                foreach ($category_cols as $val) {
                                                    if($val == 'category'){
                                                        echo "<tr><td><p class='before_input'>$val</p><textarea name=$val class=$val id=$val></textarea></td></tr>";
                                                    }
                                                }
                                                echo "</table>";
                                                echo "<input type='submit' name='add' value='".ADD."' style='position:absolute; margin-top:25px; display: block;'><div class ='text_icons'>";
                                                $category_cols = implode(',', $category_cols);
                                                echo "<input type='hidden' value=$category_cols name='cols'>";
                                                echo "<input type='hidden' value='oktavia_category' name='row'>";
                                            ?>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="tab-2">
                        <div class="workspace_tab">
                            <form method="post" action="">
                                <?php require_once("components/moduls/media/media.php"); ?>
                            </form>
                        </div>
                    </li>
                    <li class="tab-3">
                        <div class="workspace_tab">

                        </div>
                    </li>
                    <li class="tab-4">
                        <div class="workspace_tab">


                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
</body>