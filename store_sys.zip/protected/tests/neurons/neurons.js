(function($) {
	$(function() {

		function getRandom () {
			return Math.floor(Math.random( ) * 10) + 1; 
		}
		function getMax (gen) {
			return Math.max.apply(Math, gen);
		}
		function getFloor (floor) {
			return Math.floor(floor);
		}
		var first = getRandom(), 
			second = getRandom(), 
			third = getRandom(); 
			firstGen = [first + second + third, first-second-third, first*second*third, first/second/third], 
			secondGen = [first+second-third, first+second/third, first+second*third, first-second+third, first/second+third, first*second+third], 
			thirdGen = [first-second/third, first-second*third, first/second-third, first*second-third], 
			fourthGen = [first/second*third, first-second/third], 
			generations = [getFloor(getMax(firstGen)), getFloor(getMax(secondGen)), getFloor(getMax(thirdGen)), getFloor(getMax(fourthGen))];
			console.log (first, second, third);
			console.log(firstGen);
			console.log(secondGen);
			console.log(thirdGen);
			console.log(fourthGen);
			console.log(generations);
		console.log("It's okay!");
		
	});
})(jQuery);