<html>

	<head>

    	<script async type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
    	<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.js"></script>
    	<script async type="text/javascript" src="neurons.js"></script>
	
	<head>
		
	<body>
		<p>Say, hello, bitch!</p>
	</body>

</html>