<?php
session_start();
if(!isset($_SESSION['session_username'])){
    //header("location: ../protected/models/login/login.php");
}
//error_reporting( E_ERROR );
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("catalina", $connection);
$checked = $_POST['checkbox'];
$N = count($checked);
$dbtable = $_POST['row'];
$checking = $_POST['column'];
function modify() {
    for ($i = 0; $i < $GLOBALS['N']; $i++) {
        $checked = $_POST['checkbox'];
        $check = $checked[$i];
        $checking = $_POST['column'];
        $delete = $_POST['delete'];
        if (isset($delete)) {
            echo mysql_query("DELETE FROM $GLOBALS[dbtable] WHERE $checking = '$check'");
            header('location: index.php');
        }

    }
    $up_cols = array();
    $id_array = array();
    $mod = $_POST['mod'];
    if(isset($mod)){
        foreach ($GLOBALS['cols'] as $value) {
            $$value = $_POST[$value];
            echo $$value;
            array_push($up_cols, $value."='".$$value."'");
            if($value == 'id') {
                array_push($id_array, $_POST[$value]);
            }
        }
        $set = implode(", ", $up_cols);
        echo $set;
        echo "UPDATE $GLOBALS[dbtable] SET $set WHERE id = '$id_array[0]'";
        echo mysql_query("UPDATE $GLOBALS[dbtable] SET $set WHERE id = '$id_array[0]'");
        header('location: index.php');
    }
    $add = $_POST['add'];
    if(isset($add)) {

        foreach ($GLOBALS['cols'] as $value) {
            $$value = $_POST[$value];
            array_push($up_cols, "'" . $$value . "'");
        }
        $set = implode(", ", $up_cols);
        echo mysql_query("INSERT INTO $GLOBALS[dbtable] ($_POST[cols]) VALUES ($set)");
        header('location: index.php');
    }
}
$cols = explode(',', $_POST['cols']);
modify();