<style>
.survey table {
    margin-left: auto;
    margin-right: auto;
    width: 80%;
    margin-top: 0px;
}
.survey h1 {
    margin-top: 3px;
    font-size: 13px;
}
.survey h2 {
    margin-top: 0px;
    margin-bottom: 0px;
    font-size: 14px;
}
.survey p {
    margin-top: 12px;
    margin-left: 34px;
    font-size: 12px;
}
.survey td {
    padding: 20px;
    padding-left: 20px;
    padding-right: 20px;
    border: none;
    vertical-align: center;
    text-align: left;
}
/*
ROUNDED Checkbox
*/

/* ROUNDED ONE */
 .radio_button {
    width: 16px;
    margin: 10px;
    margin-top: 10px auto;
    position: relative;
}
.radio_button label {
    cursor: pointer;
    position: absolute;
    width: 16px;
    height: 16px;
    top: 2px;
    -webkit-border-radius: 8px;
    -moz-border-radius: 8px;
    border-radius: 8px;
    -webkit-box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.5), 0px 1px 0px rgba(255, 255, 255, 1);
    -moz-box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.5), 0px 1px 0px rgba(255, 255, 255, 1);
    box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.5), 0px 1px 0px rgba(255, 255, 255, 1);
    background: #fcfff4;
    background: -webkit-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: -moz-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: -o-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: -ms-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fcfff4', endColorstr='#b3bead', GradientType=0);
}
.radio_button label:after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    opacity: 0;
    content:'';
    position: absolute;
    width: 10.5px;
    height: 10.5px;
    background: #7c7c7c;
    background: -webkit-linear-gradient(top, #7c7c7c 0%, #1a1a1a 100%);
    background: -moz-linear-gradient(top, #7c7c7c 0%, #1a1a1a 100%);
    background: -o-linear-gradient(top, #7c7c7c 0%, #1a1a1a 100%);
    background: -ms-linear-gradient(top, #7c7c7c 0%, #1a1a1a 100%);
    background: linear-gradient(top, #7c7c7c 0%, #1a1a1a 100%);
    -webkit-border-radius: 25px;
    -moz-border-radius: 25px;
    border-radius: 25px;
    top: 1.5px;
    left: 3px;
    -webkit-box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0, 0, 0, 0.5);
    -moz-box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0, 0, 0, 0.5);
    box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0, 0, 0, 0.5);
}
.radio_button label:hover::after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";
    filter: alpha(opacity=30);
    opacity: 0.3;
}
.radio_button input[type=radio]:checked + label:after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
    filter: alpha(opacity=100);
    opacity: 1;
}
/*
End ROUNDED Checkbox
*/

/*
SQUARED Checkbox
*/
 .check_box {
    width: 16px;
    margin: 10px;
    margin-top: 10px auto;
    position: relative;
}
.check_box label {
    cursor: pointer;
    position: absolute;
    width: 16px;
    height: 16px;
    top: 0;
    border-radius: 4px;
    -webkit-box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0, 0, 0, 0.5);
    -moz-box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0, 0, 0, 0.5);
    box-shadow: inset 0px 1px 1px white, 0px 1px 3px rgba(0, 0, 0, 0.5);
    background: #fcfff4;
    background: -webkit-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: -moz-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: -o-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: -ms-linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    background: linear-gradient(top, #fcfff4 0%, #dfe5d7 40%, #b3bead 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fcfff4', endColorstr='#b3bead', GradientType=0);
}
.check_box label:after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    opacity: 0;
    content:'';
    position: absolute;
    width: 9px;
    height: 5px;
    background: transparent;
    top: 4px;
    left: 4px;
    border: 3px solid #333;
    border-top: none;
    border-right: none;
    -webkit-transform: rotate(-45deg);
    -moz-transform: rotate(-45deg);
    -o-transform: rotate(-45deg);
    -ms-transform: rotate(-45deg);
    transform: rotate(-45deg);
}
.check_box label:hover::after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";
    filter: alpha(opacity=30);
    opacity: 0.5;
}
.check_box input[type=checkbox]:checked + label:after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
    filter: alpha(opacity=100);
    opacity: 1;
}
/*
End SQUARED Checkbox
*/

/*
Start Radio button for school
*/
 .radio_button_sch {
    position: relative;
    margin-bottom: 15px;
    margin-top: 10px;
    margin-left: 110px;
    width: 420px;
    height: 15px;
    text-align: center;
    font-weight: bold;
    font-size: 14px;
    background: white;
    border-radius: 8px;
    padding: 5px 10px;
    outline: none;
}
.radio_button_sch label {
    position: relative;
    margin-bottom: 20px;
    width: 420px;
    height: 15px;
    text-align: center;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
    border-radius: 8px;
    color: #17c3f4;
}
.radio_button_sch label:after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    width: 420px;
    height: 15px;
    padding: 5px 10px;
    top: -22px;
    left: -222px;
    opacity: 0;
    content:"✔";
    text-align: left;
    text-indent: 1em;
    position: absolute;
    background: transparent;
    border: 3px double #53e53a;
    border-radius: 8px;
    box-shadow: 0 0 5px #5e8957;
    color: #f43006;
}
.radio_button_sch label:hover::after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";
    filter: alpha(opacity=30);
    opacity: 0.3;
}
.radio_button_sch input[type=radio]:checked + label:after {
    -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
    filter: alpha(opacity=100);
    opacity: 1;
}
</style>
<div class="survey">
    <br>
    <br>
    <table border="0" align="center">
        <tr id="1">
            <td>
                 <h1>1.</h1>

            </td>
            <td>
                 <h2>Do you do aerobic exercises 3 times a week with each session lasting more than 20 minutes?<br></h2>

                <div class="radio_button">
                    <input type="radio" value=a id="31a" name="31" style="display:none;" />
                    <label for="31a"></label>
                </div>
                <p>
                    <label for="31a">Yes</label>
                </p>
                <div class="radio_button">
                    <input type="radio" value=b id="31b" name="31" style="display:none;" />
                    <label for="31b"></label>
                </div>
                <p>
                    <label for="31b">No</label>
                </p>
            </td>
        </tr>
    </table>
</div>
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>

<script type="text/javascript">
function getStorage(key_prefix) {
    // this function will return us an object with a "set" and "get" method
    // using either localStorage if available, or defaulting to document.cookie
    if (window.localStorage) {
        // use localStorage:
        return {
            set: function (id, data) {
                localStorage.setItem(key_prefix + id, data);
            },
            get: function (id) {
                return localStorage.getItem(key_prefix + id);
            }
        };
    } else {
        // use document.cookie:
        return {
            set: function (id, data) {
                document.cookie = key_prefix + id + '=' + encodeURIComponent(data);
            },
            get: function (id, data) {
                var cookies = document.cookie,
                    parsed = {};
                cookies.replace(/([^=]+)=([^;]*);?\s*/g, function (whole, key, value) {
                    parsed[key] = unescape(value);
                });
                return parsed[key_prefix + id];
            }
        };
    }
}

jQuery(function ($) {
    // a key must is used for the cookie/storage
    var storedData = getStorage('com_hop_boxes_');

    $('div.check_box input:checkbox').bind('change', function () {
        $('#' + this.id + 'box').toggle($(this).is(':checked'));
        // save the data on change
        storedData.set(this.id, $(this).is(':checked') ? 'checked' : 'not');
    }).each(function () {
        // on load, set the value to what we read from storage:
        var val = storedData.get(this.id);
        if (val == 'checked') $(this).attr('checked', 'checked');
        if (val == 'not') $(this).removeAttr('checked');
        if (val) $(this).trigger('change');
    });
    $('div.radio_button input:radio').bind('change', function () {
        $('#' + this.id + 'box').toggle($(this).is(':checked'));
        // save the data on change
        storedData.set(this.id, $(this).is(':checked') ? 'checked' : 'not');
    }).each(function () {
        // on load, set the value to what we read from storage:
        var val = storedData.get(this.id);
        if (val == 'checked') $(this).attr('checked', 'checked');
        if (val == 'not') $(this).removeAttr('checked');
        if (val) $(this).trigger('change');
    });
    $('.addtext').bind('change', function () {
        storedData.set(this.id, $(this).val());
    }).each(function () {
        // on load, set the value to what we read from storage:
        var val = storedData.get(this.id);
        $(this).val(val);
    });
});
</script>